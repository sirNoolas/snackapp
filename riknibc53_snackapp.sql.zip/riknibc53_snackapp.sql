-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 07 jun 2014 om 22:09
-- Serverversie: 5.5.34
-- PHP-versie: 5.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `riknibc53_snackapp`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `basis_product`
--

CREATE TABLE IF NOT EXISTS `basis_product` (
  `basis_product_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `folder_id` int(10) unsigned NOT NULL,
  `basis_naam` varchar(10) NOT NULL,
  PRIMARY KEY (`basis_product_id`),
  UNIQUE KEY `basis_naam` (`basis_naam`),
  UNIQUE KEY `basis_product_id_2` (`basis_product_id`),
  UNIQUE KEY `folder_id_2` (`folder_id`),
  KEY `basis_product_id` (`basis_product_id`),
  KEY `naam` (`basis_naam`),
  KEY `folder_id` (`folder_id`),
  KEY `folder_id_3` (`folder_id`),
  KEY `basis_product_id_3` (`basis_product_id`),
  KEY `folder_id_4` (`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bestellingen`
--

CREATE TABLE IF NOT EXISTS `bestellingen` (
  `bestelling_id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`bestelling_id`),
  UNIQUE KEY `bestelling_id` (`bestelling_id`),
  UNIQUE KEY `user_id_2` (`user_id`),
  KEY `user_id` (`user_id`),
  KEY `bestelling_id_2` (`bestelling_id`),
  KEY `user_id_3` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bestellingen-producten`
--

CREATE TABLE IF NOT EXISTS `bestellingen-producten` (
  `bestelling-product_id` int(11) NOT NULL AUTO_INCREMENT,
  `bestelling_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `opmerkingen` varchar(20) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `bestel_datum` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`bestelling-product_id`),
  UNIQUE KEY `bestelling_id` (`bestelling_id`,`product_id`,`user_id`),
  UNIQUE KEY `bestelling-product_id` (`bestelling-product_id`),
  KEY `bestelling-product_id_2` (`bestelling-product_id`),
  KEY `bestelling_id_2` (`bestelling_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `folders`
--

CREATE TABLE IF NOT EXISTS `folders` (
  `folder_id` int(11) NOT NULL AUTO_INCREMENT,
  `folder_naam` varchar(10) NOT NULL,
  PRIMARY KEY (`folder_id`),
  UNIQUE KEY `folder_id_2` (`folder_id`),
  KEY `folder_id` (`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sub_products`
--

CREATE TABLE IF NOT EXISTS `sub_products` (
  `product_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `basis_product_id` int(10) unsigned NOT NULL,
  `sub_naam` varchar(10) NOT NULL,
  `prijs` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `product_id` (`product_id`),
  KEY `basis_product_id` (`basis_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  `first_name` char(12) NOT NULL,
  `last_name` char(12) NOT NULL,
  `saldo` float NOT NULL DEFAULT '0',
  `admin_value` tinyint(1) NOT NULL DEFAULT '0',
  `active` varchar(32) DEFAULT NULL COMMENT 'NULL if account activated',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `userid` (`user_id`),
  UNIQUE KEY `tokenid_2` (`token_id`),
  KEY `tokenid` (`token_id`),
  KEY `tokenid_3` (`token_id`),
  KEY `userid_2` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Gegevens worden uitgevoerd voor tabel `users`
--

INSERT INTO `users` (`user_id`, `token_id`, `email`, `password`, `first_name`, `last_name`, `saldo`, `admin_value`, `active`) VALUES
(1, NULL, 'davidvonk@live.nl', '000458e5772683b96be3e8b2512ac5bf', 'David', 'Vonk', 1000000, 1, NULL),
(8, NULL, 'david@itspixeled.nl', '786f2d0acade1787dacb21cac85d099c', 'David', 'Vonk', 0, 0, '77e9490a7063bdf79491117224bfa802');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
